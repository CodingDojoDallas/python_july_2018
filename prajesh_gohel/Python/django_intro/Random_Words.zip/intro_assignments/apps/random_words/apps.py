from django.apps import AppConfig


class RandomWordsConfig(AppConfig):
    name = 'random_words'
