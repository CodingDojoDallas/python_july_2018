from django.apps import AppConfig


class ViewConfig(AppConfig):
    name = 'view'
