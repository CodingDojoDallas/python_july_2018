from django.apps import AppConfig


class EditConfig(AppConfig):
    name = 'edit'
