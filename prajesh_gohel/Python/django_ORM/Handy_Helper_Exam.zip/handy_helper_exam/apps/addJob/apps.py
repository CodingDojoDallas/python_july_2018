from django.apps import AppConfig


class AddjobConfig(AppConfig):
    name = 'addJob'
