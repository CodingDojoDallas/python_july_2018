from django.apps import AppConfig


class WallAppConfig(AppConfig):
    name = 'wall_app'
